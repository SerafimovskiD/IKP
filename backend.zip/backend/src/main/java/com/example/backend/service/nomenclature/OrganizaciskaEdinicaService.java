package com.example.backend.service.nomenclature;

import java.util.UUID;

import com.example.backend.dto.OrgEdinicaRequest;
import com.example.backend.dto.OrgEdinicaResponse;
import com.example.backend.exceptions.ResourceNotFoundException;
import com.example.backend.model.OrganizaciskaEdinica;
import com.example.backend.repository.orgEdinicaRepository;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class OrganizaciskaEdinicaService {
    private final orgEdinicaRepository orgEdinicaRepository;

    public OrganizaciskaEdinicaService(orgEdinicaRepository orgEdinicaRepository) {
        this.orgEdinicaRepository = orgEdinicaRepository;
    }

    @Cacheable("orgEdinici")
    public List<OrgEdinicaResponse> findAll() {
        return OrgEdinicaResponse.from(orgEdinicaRepository.findAll());
    }

    @Cacheable(value = "orgEdiniciById", key = "#id")
    public OrgEdinicaResponse findById(UUID id) {
        return OrgEdinicaResponse.from(orgEdinicaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Organizaciska edinica", id)));
    }

    @CacheEvict(value = {"orgEdinici", "orgEdiniciById"}, allEntries = true)
    public OrgEdinicaResponse create(OrgEdinicaRequest orgEdinicaRequest) {
        OrganizaciskaEdinica organizaciskaEdinica = new OrganizaciskaEdinica();
        organizaciskaEdinica.setNaziv(orgEdinicaRequest.getNaziv());
        organizaciskaEdinica.setCode(orgEdinicaRequest.getCode());
        return OrgEdinicaResponse.from(orgEdinicaRepository.save(organizaciskaEdinica));
    }

    @CacheEvict(value = {"orgEdinici", "orgEdiniciById"}, allEntries = true)
    public OrgEdinicaResponse update(UUID id, OrgEdinicaRequest orgEdinicaRequest) {
        OrganizaciskaEdinica organizaciskaEdinica = orgEdinicaRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Organizaciska edinica so id: " + id + " ne postoi"));
        organizaciskaEdinica.setNaziv(orgEdinicaRequest.getNaziv());
        organizaciskaEdinica.setCode(orgEdinicaRequest.getCode());
        return OrgEdinicaResponse.from(orgEdinicaRepository.save(organizaciskaEdinica));
    }

    @CacheEvict(value = {"orgEdinici", "orgEdiniciById"}, allEntries = true)
    public void delete(UUID id) {
        orgEdinicaRepository.deleteById(id);
    }
}