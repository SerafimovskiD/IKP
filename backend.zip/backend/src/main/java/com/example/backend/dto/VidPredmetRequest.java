package com.example.backend.dto;

import lombok.Data;

@Data
public class VidPredmetRequest {
    public String naziv;

}
