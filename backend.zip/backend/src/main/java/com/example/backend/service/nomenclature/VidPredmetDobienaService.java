package com.example.backend.service.nomenclature;

import java.util.UUID;

import com.example.backend.dto.VidPredmetRequest;
import com.example.backend.exceptions.ResourceNotFoundException;
import com.example.backend.model.VidPredmetDobiena;
import com.example.backend.repository.VidPredmetDobienaRepository;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class VidPredmetDobienaService {
    private final VidPredmetDobienaRepository vidPredmetRepository;

    public VidPredmetDobienaService(VidPredmetDobienaRepository vidPredmetRepository) {
        this.vidPredmetRepository = vidPredmetRepository;
    }

    @Cacheable("vidPredmetDobiena")
    public List<VidPredmetDobiena> getAllVidPredmet() {
        return this.vidPredmetRepository.findAll();
    }

    public VidPredmetDobiena getVidPredmetById(UUID id) {
        return this.vidPredmetRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Вид на предмет", id));
    }

    @CacheEvict(value = "vidPredmetDobiena", allEntries = true)
    public VidPredmetDobiena createVidPredmet(VidPredmetRequest request) {
        VidPredmetDobiena vidPredmet = new VidPredmetDobiena();
        vidPredmet.setNaziv(request.getNaziv());
        return this.vidPredmetRepository.save(vidPredmet);
    }

    @CacheEvict(value = "vidPredmetDobiena", allEntries = true)
    public VidPredmetDobiena updateVidPredmet(UUID id, VidPredmetRequest request) {
        VidPredmetDobiena existingVidPredmet = this.getVidPredmetById(id);
        existingVidPredmet.setNaziv(request.getNaziv());
        return this.vidPredmetRepository.save(existingVidPredmet);
    }

    @CacheEvict(value = "vidPredmetDobiena", allEntries = true)
    public void deleteVidPredmetById(UUID id) {
        VidPredmetDobiena existingVidPredmet = this.getVidPredmetById(id);
        this.vidPredmetRepository.delete(existingVidPredmet);
    }
}